package com.saem.aop;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

public class Test2 {

	public static void main(String[] args) {
		String str2 = "%EB%93%B1%EB%AA%85%ED%95%B4%EB%B3%80%EA%B4%80%EA%B4%91%EC%A7%80";
		String str = "등명해변관광지";
		try {
			String result = URLEncoder.encode(str, "utf8");
			if(result.equals(str2)) {
				System.out.println("같다");
			} else { 
				System.out.println("다르다");
			}
			System.out.println(result);
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
